#!/bin/bash

# This script compiles and runs all testbenches for the Verilog modules.

# Exit immediately if a command exits with a non-zero status.
set -e

echo "Compiling Verilog sources and testbenches..."

# List of all source Verilog files that are dependencies for the testbenches
# Note: top.v is not needed here as it's a top-level design, not a submodule for other tests.
SOURCES="\
ourwork/oai_mult.v \
ourwork/add.v \
ourwork/s_cla.v \
ourwork/se_cla.v \
ourwork/gctrl.v \
ourwork/rwldrv.v \
ourwork/accumulator.v \
ourwork/cim_array_ctrl.v \
ourwork/cim_bank.v \
ourwork/cim_array.v \
ourwork/local_mac.v \
ourwork/global_io.v \
ourwork/digit_circuit.v"

# Function to compile and run a single testbench
run_test() {
    local tb_file=$1
    local test_name=$(basename $tb_file .v)
    local output_file="ourwork/test/${test_name}.out"
    
    echo "\n--- Running test: ${test_name} ---"
    
    # Compile the specific testbench with all necessary source files
    iverilog -o ${output_file} $SOURCES $tb_file
    
    # Run the compiled simulation
    vvp ${output_file}
}

# Run tests for each module
run_test ourwork/test/oai_mult_tb.v
run_test ourwork/test/add_tb.v
run_test ourwork/test/s_cla_tb.v
run_test ourwork/test/se_cla_tb.v
run_test ourwork/test/gctrl_tb.v
run_test ourwork/test/rwldrv_tb.v
run_test ourwork/test/accumulator_tb.v
run_test ourwork/test/cim_array_ctrl_tb.v
run_test ourwork/test/cim_bank_tb.v
run_test ourwork/test/cim_array_tb.v
run_test ourwork/test/local_mac_tb.v
run_test ourwork/test/global_io_tb.v
run_test ourwork/test/digit_circuit_tb.v

echo "\nAll tests completed successfully."

